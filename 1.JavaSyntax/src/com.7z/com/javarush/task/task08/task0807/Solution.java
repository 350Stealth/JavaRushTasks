package com.javarush.task.task08.task0807;

import java.util.ArrayList;
import java.util.LinkedList;

/* 
LinkedList и ArrayList
*/

public class Solution {
    public static Object createArrayList() {
        //напишите тут ваш код
        ArrayList<Object> arrayList = new ArrayList<>();
        return arrayList;

    }

    public static Object createLinkedList() {
        //напишите тут ваш код
        LinkedList<Object> linkedList = new LinkedList<>();
        return linkedList;

    }

    public static void main(String[] args) {

    }
}
