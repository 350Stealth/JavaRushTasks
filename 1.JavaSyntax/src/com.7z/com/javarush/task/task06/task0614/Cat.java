package com.javarush.task.task06.task0614;

import java.util.ArrayList;

/* 
Статические коты
*/

public class Cat {
    //напишите тут ваш код
    public static ArrayList<Cat> cats;

    public Cat() {
    }

    public static void main(String[] args) {
        //напишите тут ваш код
        printCats();
    }

    public static void printCats() {
        //напишите тут ваш код
    }
}
