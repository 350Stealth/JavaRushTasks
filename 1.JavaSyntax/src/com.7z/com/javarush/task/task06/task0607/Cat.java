package com.javarush.task.task06.task0607;

/* 
Классовый счетчик
*/

public class Cat {
    //напишите тут ваш код
    private static int catCount;
    
    public Cat() {
        catCount++;
    }

    public static void main(String[] args) {

    }
}
