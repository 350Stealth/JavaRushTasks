package com.javarush.task.task03.task0303;

/* 
Обмен валют
*/

public class Solution {
    public static void main(String[] args) {
        //напишите тут ваш код
        System.out.println(convertEurToUsd(75, 2.15));
        System.out.println(convertEurToUsd(112, 2.15));
    }

    public static double convertEurToUsd(int eur, double course) {
        //напишите тут ваш код
        return (eur * course);
    }
}
